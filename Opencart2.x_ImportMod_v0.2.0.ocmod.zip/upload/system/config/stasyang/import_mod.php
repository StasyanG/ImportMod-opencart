<?php
$_['importmod_path'] = 'tool/import_mod';
$_['importmod_model'] = 'model_tool_import_mod';
$_['importmod_name'] = 'import_mod';
$_['importmod_version'] = '0.2.0';