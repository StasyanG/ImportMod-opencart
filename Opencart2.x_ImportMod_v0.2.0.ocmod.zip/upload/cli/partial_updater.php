<?php
	$cli_action = 'tool/import_mod/all_partial_update';
	require_once('cli_dispatch.php');
?>